package myArrayList.util;

import java.util.Arrays;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import myArrayList.util.FileProcessor;
import myArrayList.util.MyArrayList;
import java.util.Iterator;
import java.util.Queue;
import java.lang.NullPointerException;
import java.util.LinkedList;
import java.io.*;


public class MyArrayList {

	private static final int capacity =30;
	private Integer array3[];
	Queue<Integer> queue1;
	int counter=0;

	/*Methods of myArrayList
	*/

	/*Constructor
	*/
	public MyArrayList(){
		array3 = new Integer[capacity];
		queue1 = new LinkedList<>();
	}



	/*Function for increasing the size of the array
	*/
	private void resize(){
		int newCapacity = 2* array3.length;
		Integer newArr[] = new Integer[newCapacity];
		//System.out.println("Resize Working");
		for(int i=0;i<array3.length;i++)
			newArr[i]=array3[i];
		array3=newArr;
	}

	


    /*Function for Inserting Value and keep it sorted
    */

	public void insertSorted(int newValue){  
		if(newValue>=0 && newValue<=10000){   
		if(counter==array3.length)
			resize();
		int templength=counter;
		counter++;
		array3[templength]=newValue;
		queue1.add(newValue);
		

		/*Insertion Sort is used to sort this Array
		*/
	        for (int i = 0; i <= templength; ++i) { 
	            int key = array3[i]; 
	            int j = i - 1; 
	  
	            /* Move elements of arr[0..i-1], that are 
	               greater than key, to one position ahead 
	               of their current position */
	            while (j >= 0 && array3[j] > key) { 
	                array3[j + 1] = array3[j]; 
	                j = j - 1; 
	            } 
	            array3[j + 1] = key; 
	        }
		}
	}

	/*Function for Removing Value and keep it sorted
    */
	public void removeValue(int value){
		for(int i = 0; i < counter; i++){
            if(array3[i] == value){
                for(int j = i; j < counter - 1; j++){
                    array3[j] = array3[j+1];
                }
                counter--;
                break;
            }
        }
	}


	/*Function for printing the elements in inserted order
    */
	public void printInsertionOrder(){
		Iterator it = queue1.iterator();
		System.out.println("Insertion order for array:");
		while(it.hasNext()){
			System.out.println(it.next()+" ");
		}
	}
	
	

	/*Function for compact method
    */
	public void compact(){
		Integer newArr[] = new Integer[counter];
		//System.out.println("Resize2 Working");
		for(int i=0;i<newArr.length;i++)
			newArr[i]=array3[i];
		array3=newArr;
	}




	/*Function for finding the index of the passed value 
	*
	*Using Binary search for better faster calculation
    */
	public int indexOf(int value){							
			int low = 0, high = counter-1; 						
        	while (low <= high) { 							
            int mid = low + (high - low) / 2; 
  
            if (array3[mid] == value) 
                return mid; 
  
            // If value greater, ignore left half 
            if (array3[mid] < value) 
                low = mid + 1; 
  
            // If value is smaller, ignore right half 
            else
                high = mid - 1; 
        } 
  
        /* if we reach here, then element was 
        * not present 
         */
        return -1; 
		}


	/*Function for finding the length of the array 
	*/
	public int arrayListLength(){
		return array3.length;
	}


	/*Function for finding the the total elements present in the array 
	*/
	public int size(){
		return counter;
	}


	/*Function for finding the sum of the array
	*/
	int sum1=0;
	public int sum(){
		for(int i=0;i<counter;i++)
			sum1+=array3[i];
		return sum1;
	}

	//@Override
	public void toString1(){
		System.out.println();
		System.out.println("The Length of the array is " + array3.length);
		System.out.println();
		System.out.println("The Contents of the array are");
		for(int i=0;i<array3.length;i++){
			System.out.println("Array ["+i+"]="+array3[i]);
		}

	}

}