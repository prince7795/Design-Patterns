/////Logger.java////////////

package myArrayList.util;

public interface Logger {
	
}