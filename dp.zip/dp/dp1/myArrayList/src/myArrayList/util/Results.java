
package myArrayList.util;
	
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.Vector;
import java.util.List;


public class Results implements FileDisplayInterface, StdoutDisplayInterface {

	/**Declaring a data structure 
	**/
	private List<String> resultList=new Vector<String>();
	
	/**
	Declaring an empty String to store the result got from test file
	**/
	String res = "";



	/** Storing the incoming result in a data Structure
	**/
	public void storeNewResult(String res) {
		resultList.add(res);
		writeToStdout(res);
	}
	


	/** Used to write to console
	**/
	public void writeToStdout(String s) {
		System.out.println(s + " \n");
	}
	
	
	/*** Used to write to a file
	***/
	public void writeToFile(String s) 
	{
		// Writing to a file using BufferedWriter in Java
        try {
            FileWriter writer = new FileWriter(s);
            BufferedWriter bwr = new BufferedWriter(writer);
            for(String st : resultList)
			{	
				
				bwr.write(st);
				bwr.newLine();
				bwr.write("\r\n");
			}
            bwr.close();
           // System.out.println("succesfully written to a file");
            
        } catch (Exception ioe) {
            System.out.println("Invalid");
        }
	}
}
