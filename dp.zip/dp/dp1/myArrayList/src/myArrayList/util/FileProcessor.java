package myArrayList.util;

import java.io.IOException;
//import java.io.*;
import java.io.FileReader;
import java.io.BufferedReader;


public class FileProcessor {

	public FileProcessor(){}
		FileReader fp = null;
		BufferedReader br =null;
	

	public void initializeFile(String filename){
		try{
			fp = new FileReader(filename);
			br = new BufferedReader(fp);
		}
		catch(Exception e){
			System.out.println("Error");
		}
	}

	public String readLine(){
		String line= null;
		try {  
		line = br.readLine();
		   // br.close();
		} 
		catch(Exception e) {
		    System.out.println("File not Found");
		}
		return line;
	}

}


