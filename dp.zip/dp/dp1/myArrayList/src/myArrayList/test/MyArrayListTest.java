
package myArrayList.util;
import myArrayList.util.MyArrayList;
import java.util.Arrays;
import myArrayList.util.Results;

public class MyArrayListTest{
	/**
	*Contains all the testcases which are defined below
	**/
	public void testme(MyArrayList myArrayList, Results results){
		sizeTest(myArrayList,results);
		sizeConditionTest(myArrayList,results);
		indexTest(myArrayList,results);
		sortingIndexTest(myArrayList,results);
		resizeTest(myArrayList,results);
		sumTest(myArrayList,results);
		removalTest(myArrayList,results);
		removalSumTest(myArrayList,results);
		noValueIndexTest(myArrayList,results);
		compactTest(myArrayList,results);
	}

	/**
	* Test1 designed to check whether size function returns right Value
	**/
	public void sizeTest(MyArrayList myArrayList, Results results){
		myArrayList.insertSorted(15);
		myArrayList.insertSorted(25);
		myArrayList.insertSorted(11);
		myArrayList.insertSorted(55);
		myArrayList.insertSorted(5);
		if(myArrayList.size()==5)	
			results.storeNewResult("Test1(sizeTest) : PASSED");
		else
			results.storeNewResult("Test1(sizeTest) : FAILED");
	}
	
	/**
	* Test2 designed to check whether size function returns right Value under specified Constraints
	**/
	public void sizeConditionTest(MyArrayList myArrayList, Results results){
		myArrayList.insertSorted(-2);
		myArrayList.insertSorted(24);
		myArrayList.insertSorted(-66);
		myArrayList.insertSorted(235);
		myArrayList.insertSorted(1);
		myArrayList.insertSorted(20000);
		myArrayList.insertSorted(30000);
		myArrayList.insertSorted(-186);
		if(myArrayList.size()==3)	
			results.storeNewResult("Test2(sizeConditionTest) : PASSED");
		else
			results.storeNewResult("Test2(sizeConditionTest) : FAILED");
	}


	/**
	* Test3 designed to check whether indexOf() returns correct value when inserted in sorted manner
	**/
	public void indexTest(MyArrayList myArrayList, Results results){
		myArrayList.insertSorted(1);
		myArrayList.insertSorted(2);
		myArrayList.insertSorted(3);
		myArrayList.insertSorted(4);
		myArrayList.insertSorted(5);
		myArrayList.insertSorted(6);
		myArrayList.insertSorted(7);
		myArrayList.insertSorted(8);
		if(myArrayList.indexOf(5)==4)	
			results.storeNewResult("Test3(IndexTest) : PASSED");
		else
			results.storeNewResult("Test3(IndexTest) : FAILED");
	}


	/**
	* Test4 designed to check whether indexOf() returns correct value
	* when elements are inserted in unsorted manner
	**/
	public void sortingIndexTest(MyArrayList myArrayList, Results results){
		myArrayList.insertSorted(5);
		myArrayList.insertSorted(2);
		myArrayList.insertSorted(-66);
		myArrayList.insertSorted(100);
		myArrayList.insertSorted(469);
		myArrayList.insertSorted(20088);
		myArrayList.insertSorted(30);
		myArrayList.insertSorted(786);
		if(myArrayList.indexOf(2)<myArrayList.indexOf(5) && myArrayList.indexOf(5)<myArrayList.indexOf(30) 
			&& myArrayList.indexOf(30)<myArrayList.indexOf(100)&& myArrayList.indexOf(100)<myArrayList.indexOf(469)
			&& myArrayList.indexOf(469)<myArrayList.indexOf(786))	
			results.storeNewResult("Test4(sortingIndexTest) : PASSED");
		else
			results.storeNewResult("Test4(sortingIndexTest) : FAILED");
	}


	/**
	* Test5 designed to check whether array automatically increases its size 
	* once we enter elements more than its default capacity.
	* 
	* Here the default capacity of the myArrayList is 30, as soon as 31st 
	* element is inserted it will call the resize function and double the 
	* size of the array.
	**/
	public void resizeTest(MyArrayList myArrayList, Results results){
		for(int i=1;i<=40;i++)
			myArrayList.insertSorted(i);
		myArrayList.insertSorted(31);
		if(myArrayList.arrayListLength()==60)	
			results.storeNewResult("Test5(resizeTest) : PASSED");
		else
			results.storeNewResult("Test5(resizeTest) : FAILED");
	}
	
	/**
	* Test6 designed to check whether the method sum returns the correct value 
	**/
	public void sumTest(MyArrayList myArrayList, Results results){
		int a=31;
		int b=100;
		int c=1034;
		int d=998;
		myArrayList.insertSorted(a);
		myArrayList.insertSorted(b);
		myArrayList.insertSorted(c);
		myArrayList.insertSorted(d);
		int tempSum=a+b+c+d;
		if(myArrayList.sum()==tempSum)	
			results.storeNewResult("Test6(sumTest) : PASSED");
		else
			results.storeNewResult("Test6(sumTest) : FAILED");
	}

	/**
	* Test7 designed to check whether the method removeValue works correctly 
	**/
	public void removalTest(MyArrayList myArrayList, Results results){
		myArrayList.insertSorted(15);
		myArrayList.insertSorted(25);
		myArrayList.insertSorted(11);
		myArrayList.insertSorted(55);
		myArrayList.insertSorted(5);
		myArrayList.insertSorted(25);
		int temp1 = myArrayList.size();
		myArrayList.removeValue(5);
		int temp2 = myArrayList.size();

		if(temp1>temp2)	
			results.storeNewResult("Test7(removalTest) : PASSED");
		else
			results.storeNewResult("Test7(removalTest) : Failed");
	}

	/**
	* Test8 designed to check whether the method sum returns the correct value after removing some Value
	**/
	public void removalSumTest(MyArrayList myArrayList, Results results){
		int a=4;
		int b=25;
		int c=345;
		int d=53;
		int e=1;
		myArrayList.insertSorted(a);
		myArrayList.insertSorted(b);
		//myArrayList.insertSorted(c);
		myArrayList.insertSorted(d);
		myArrayList.insertSorted(e);
		myArrayList.insertSorted(c);
		myArrayList.removeValue(c);
		int tempSum=a+b+d+e;

		if(myArrayList.sum()==tempSum)	
			results.storeNewResult("Test8(removalSumTest) : PASSED");
		else
			results.storeNewResult("Test8(removalSumTest) : FAILED");
	}

	/**
	* Test9 designed to check whether indexOf() returns -1 when 
	**/
	public void noValueIndexTest(MyArrayList myArrayList, Results results){
		myArrayList.insertSorted(1);
		myArrayList.insertSorted(2);
		myArrayList.insertSorted(3);
		myArrayList.insertSorted(4);
		myArrayList.insertSorted(5);
		myArrayList.insertSorted(6);
		myArrayList.insertSorted(7);
		myArrayList.insertSorted(8);
		if(myArrayList.indexOf(54)==-1)	
			results.storeNewResult("Test 9(noValueIndexTest) : PASSED");
		else
			results.storeNewResult("Test 9(noValueIndexTest) : FAILED");
	}

	/**
	* Test10 designed to check whether Compact method works 
	**/
	public void compactTest(MyArrayList myArrayList, Results results){
		myArrayList.insertSorted(12);
		myArrayList.insertSorted(21);
		myArrayList.insertSorted(31);
		myArrayList.insertSorted(14);
		myArrayList.insertSorted(45);
		myArrayList.insertSorted(64);
		myArrayList.insertSorted(22);
		myArrayList.insertSorted(33);
		myArrayList.insertSorted(65);
		myArrayList.insertSorted(441);
		myArrayList.insertSorted(111);
		myArrayList.insertSorted(563);
		myArrayList.insertSorted(8);
		int temp1=myArrayList.size();
		myArrayList.removeValue(45);
		myArrayList.removeValue(22);
		myArrayList.removeValue(64);
		myArrayList.removeValue(563);
		myArrayList.removeValue(33);
		myArrayList.compact();
		int temp2=myArrayList.size();

		if(temp2<temp1)	
			results.storeNewResult("Test 10(compactTest) : PASSED");
		else
			results.storeNewResult("Test 10(compactTest) : FAILED");
	}

	
}


