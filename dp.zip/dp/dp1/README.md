# CSX42: Assignment 1
## Name: Prince Rajaram Singh
### BNumber: B00767056

-----------------------------------------------------------------------
-----------------------------------------------------------------------


Following are the commands and the instructions to run ANT on your project.
#### Note: build.xml is present in myArrayList/src folder.

-----------------------------------------------------------------------
## Instruction to clean:

####Command: ant -buildfile myArrayList/src/build.xml clean

Description: It cleans up all the .class files that were generated when you
compiled your code.

-----------------------------------------------------------------------
## Instruction to compile:

####Command: ant -buildfile myArrayList/src/build.xml all

Description: Compiles your code and generates .class files inside the BUILD folder.

-----------------------------------------------------------------------
## Instruction to run:

####Command: ant -buildfile myArrayList/src/build.xml run -Darg0=<input_file.txt> -Darg1=<output_file.txt> 

Note: Arguments accept the absolute path of the files.


-----------------------------------------------------------------------
## Description:
Developed a myArrayList with its util and driver packages implemented in it and different type of methods.
Different type of testcases were also constructed to check the working of this methods.

The default size of the array is 30 at first and if it goes above 30 it will increase the size by 
multiplying the original size by 2.


Different Methods:
1. insertSorted(int value) : I used insertion sort to sort the array as insertion sort provides better time
	complexity than the other sorting algorithms present.

2. getIndexOf(int value) : I used binary search to determine the position of the input value. Since Binary 
	search requires the values to be sorted at first which in our case is fulfilled so I took advantage 
	of that and used it.
	The Time complexity using this came to be logN.

Data Structure used for printInsertionOrder : I used inbuilt queue data structure to keep track of all
inserted element and then I iterated over the queue to print the content in it. As queue is very easy to
use and also the time complexity to print all the values will be N using the queue iterator.

The MyArrayListTest contains 10 testcases which are written in mytest() method. 

Note: When running each testcase individually, it will run perfectly and will yield PASSED output but when
running testMe() will yield FAILED output in some testcases because of shared array.

-----------------------------------------------------------------------
### Academic Honesty statement:
-----------------------------------------------------------------------

"I have done this assignment completely on my own. I have not copied
it, nor have I given my solution to anyone else. I understand that if
I am involved in plagiarism or cheating an official form will be
submitted to the Academic Honesty Committee of the Watson School to
determine the action that needs to be taken. "

Date: 06/17/2019 


