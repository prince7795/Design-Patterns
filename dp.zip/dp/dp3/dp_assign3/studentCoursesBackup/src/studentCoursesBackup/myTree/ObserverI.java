package studentCoursesBackup.myTree;
 
   public interface ObserverI {
    
		public void update(node n);
					  
}