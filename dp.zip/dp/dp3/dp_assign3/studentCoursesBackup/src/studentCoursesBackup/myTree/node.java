package studentCoursesBackup.myTree;

import studentCoursesBackup.util.MyLogger.DebugLevel;
import studentCoursesBackup.util.MyLogger;
import java.util.ArrayList; 
import java.util.Iterator; 
import studentCoursesBackup.myTree.ObserverI;
import studentCoursesBackup.util.TreeBuilder;
 
 
public class node implements SubjectI,ObserverI{	
	
	//ArrayList<ObserverI> observerList; 
	public int key;
	public String value;
	public ArrayList<String> courseList = new ArrayList<String>();
	public node left, right;
	private ArrayList<node> observerList = new ArrayList<>();
	node backUp1;
	node backUp2;
  
    public node() { 
        
		
    } 
	
	public node(int item,String s) { 
				this.key = item; 
				this.value = s;
				this.courseList.add(s);
				this.left = this.right = null; 
	}
  
	/*public node(node n) { 
				this.key = node.key; 
				this.value = node.value;
				ArrayList<String> courseCopyList = new ArrayList<>(this.courseList);
				this.left = this.right = null; 
	}*/
	
    @Override
    public void registerObserver(node o) { 
       
    } 
  
    @Override
    public void unregisterObserver(node o) { 
        observerList.remove(observerList.indexOf(o)); 
    } 
  
    @Override
    public void notifyObservers(node n) { 
        this.backUp1.update(n);
		this.backUp2.update(n);
    }
	
	
	public node getbackUp1() {
		return backUp1;
	}


	public void setListnerBackUp1(node backUp1) {
		backUp1 = backUp1;
	}

	
	public node getbackUp2() {
		return backUp2;
	}

	
	public void setgetbackUp2(node getbackUp2) {
		backUp2 = backUp2;
	}
	
	public ArrayList<String> getcourseList(){
		return courseList;
	}
	

    /*
     * get the listner list
     */
    public ArrayList<node> getobserverList()
    {
        return observerList;
    }

    /*
     * override the clone method from Cloneable
     */
   // @Override
    public node copyNode(node root1,node backupNode11){
		node newNode=null;
		if (root1 == null)
        {
            return null;
        }
		node temp2;
		temp2=Search(root1.key,backupNode11);
		//System.out.println("Hello"+temp2.key);
		if(temp2 == null){
        newNode = new node(root1.key,root1.value);
		}
		else{
			//System.out.println("Hello"+temp2.key);
			temp2.courseList.add(root1.value);
			return temp2;
		}
		newNode.left= root1.copyNode(root1.left,backupNode11);
        newNode.right= root1.copyNode(root1.right,backupNode11);
		return newNode;
		
         
    }
	
	@Override
	public void update(node n) {
			
	}
	
	 /**
	 * @param the Key 
	 * A utility function to searchnode
	 * @return the node
	 */
	 node Search(int key, node backupNode11) {
		node temp = backupNode11;
		while (temp != null) {
				if ((temp.key) == key) {
					return temp;
				} else if (temp.key > key) {
					temp = temp.left;
				} else if (temp.key < key) {
					temp = temp.right;
				}
		}
		return null;
	}
    
	
}