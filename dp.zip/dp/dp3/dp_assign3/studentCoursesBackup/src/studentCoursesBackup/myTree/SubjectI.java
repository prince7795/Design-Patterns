package studentCoursesBackup.myTree;
 
   public interface SubjectI{
	   
		public void registerObserver(node o); 
		public void unregisterObserver(node o); 
		public void notifyObservers(node n); 
    
}