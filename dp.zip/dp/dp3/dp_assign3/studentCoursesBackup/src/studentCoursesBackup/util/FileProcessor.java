package studentCoursesBackup.util;

import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;
import studentCoursesBackup.util.MyLogger.DebugLevel;

public class FileProcessor {
	
	//MyLogger ml = new MyLogger();

	public FileProcessor(){ 
	MyLogger.writeMessage ("FileProcessor Constructor called",DebugLevel.CONSTRUCTOR);
	}
		FileReader fp = null;
		BufferedReader br =null;
	
	
	
	/**
	* @param The input file name will be passed
	* This function will create object which will be used by method readLine
	* @return nothing
	*/
	public void initializeFile(String filename){
		try{
			fp = new FileReader(filename);
			br = new BufferedReader(fp);
			MyLogger.writeMessage ("Input File Opened Here",DebugLevel.INPUTFILEOPERATION);
		}
		catch(Exception e){
			System.out.println("Error");
		}
		finally{}
	}
	
	
	/**
	* @param nothing
	* Reads 1 line from the input file
	* @return string which contains entire line in the input file           
	*/
	public String readLine(){
		String line= null;
		try {  
		line = br.readLine();
		   // br.close();
		} 
		catch(Exception e) {
		    System.out.println("File not Found");
		}
		return line;
	}

}


