package studentCoursesBackup.util;

import studentCoursesBackup.myTree.node;
import java.util.List;
import java.util.ArrayList;
import studentCoursesBackup.util.MyLogger.DebugLevel;
import studentCoursesBackup.util.MyLogger;
import studentCoursesBackup.util.Results;


public class TreeBuilder{
		
	/**
	* @param get the FileProcessor object from Driver.java
	* Store the data got from read line into arrays            
	*/
	public void getData(FileProcessor finput,FileProcessor fdelete,Results r){
		
		/*
		* Input File Reading done here
		*/
		
		ArrayList<Integer> arr1 = new ArrayList<Integer>();
		ArrayList<String> arr2 = new ArrayList<String>();
		
		String myString="";
		while((myString = finput.readLine()) != null){
			String parts[] = myString.split(":");
			arr1.add(Integer.parseInt(parts[0]));
			arr2.add(parts[1]);
			//System.out.println(myString);
			}
			for (int i=0; i<arr1.size(); i++) {
				////put the if condition here ////////////
				//////////////////////////////////////////
				if( arr1.get(i) > 0 &&  arr1.get(i)<10000) 				
					put( arr1.get(i), arr2.get(i));
				else{
					System.out.println("Invalid Bnumber provided in the Input file");
				}
			}
			
			

			System.out.println();
			//printNodes(r);
			
			/*Delete File Reading done here*/
			ArrayList<Integer> arr3 = new ArrayList<Integer>();
			ArrayList<String> arr4 = new ArrayList<String>();
			String myString2="";
			while((myString2 = fdelete.readLine()) != null){
				String parts2[] = myString2.split(":");
				arr3.add(Integer.parseInt(parts2[0]));
				arr4.add(parts2[1]);
				//System.out.println("Hello");
				//System.out.println(myString2);
				}
				for (int i=0; i<arr3.size(); i++) {
					////put the if condition here ////////////
					//////////////////////////////////////////
					
					deleteValue( arr3.get(i), arr4.get(i));
			}
			
			backupNode11 = root1.copyNode(root1,backupNode11);
			backupNode21 = root1.copyNode(root1,backupNode21);
			
		}
		
		
		
		/* TreeBuilder methods starts here */
		
		/*   Created BinarySearchTree and took help from geeksforgeeks 	*/
		/* https://www.geeksforgeeks.org/binary-search-tree-set-1-search-and-insertion/ */
					
		public node root1;
		public node backupNode11;
		node backupNode21;
		
		// Constructor 
		public TreeBuilder() {  
			MyLogger.writeMessage ("TreeBuilder Constructor called",DebugLevel.CONSTRUCTOR);
			node root1=null;
			node backupNode11=null;
			node backupNode21=null;	
		} 
		
		
		/**
	* @param The input will be the key and the value to store in the node
	* Call insertRec Function
	* @return nothing
	*/
    public void put( Integer key, String s ) {
		node temp2;
		temp2=SearchNode(key);
		if(temp2==null)
			root1 = insertRec(root1, key, s);
		else 	
			temp2.courseList.add(s);		
	}
	
	
	/**
	* @param The input will be the key and the value to store in the node
	* if key not found in BST then it is added. If key already exists then that node's value
      is updated.
	* @return the node
	*/
    node insertRec(node root1, int key, String s) {   
        /* If the tree is empty, return a new node */
        if (root1 == null) { 
            root1 = new node(key, s); 
            return root1; 
        } 
  
        /* Otherwise, recur down the tree */
        if (key < root1.key) 
            root1.left = insertRec(root1.left, key, s); 
        else if (key > root1.key) 
            root1.right = insertRec(root1.right, key, s); 
  
        /* return the (unchanged) node pointer */
        return root1; 
    }


	
	/**
	* @param nothing
	* This method mainly calls InorderRec() 
	* @return nothing
	*/
    public void printNodes1(Results r1, Results r2, Results r3)  { 
	   System.out.println("This is the original tree");
       inorderRec(root1,r1);
	   System.out.println("This is the backupNode1 tree");
       inorderRec(backupNode11,r2);	  
	   System.out.println("This is the backupNode2 tree");
       inorderRec(backupNode21,r3); 
    } 	
	
	
	/**
	* @param the root node
	* A utility function to do inorder traversal of BST 
	* @return nothing
	*/ 
    void inorderRec(node root1, Results r) { 
        if (root1 != null) { 
            inorderRec(root1.left,r); 
			
            System.out.print(root1.key + " : ");
			for (String items: root1.courseList)
				System.out.print(items + " ");
			String listString = String.join(" ", root1.courseList);
			System.out.println();
			r.storeNewResult(String.valueOf(root1.key)+":"+listString);
            inorderRec(root1.right,r); 
        } 
    }
	
	
	/**
	* @param the root node, Key and value to be deleted
	* A utility function to delete
	* @return the node
	*/
    node deleteValue(int key, String s)  {
		node temp = root1;		
		while (temp != null) {
				if ((temp.key) == key) {
					for(String i : temp.courseList){
						if(i.matches(s)){
							temp.courseList.remove(new String(s));
						}
					}						
					return temp;
				} 
				else if (temp.key > key) {
					temp = temp.left;
				} else if (temp.key < key) {
					temp = temp.right;
				}
		}
		return null;
		
	}
	
	
	
	 /**
	 * @param the Key 
	 * A utility function to searchnode
	 * @return the node
	 */
	 node SearchNode(int key) {
		node temp = root1;
		while (temp != null) {
				if ((temp.key) == key) {
					return temp;
				} else if (temp.key > key) {
					temp = temp.left;
				} else if (temp.key < key) {
					temp = temp.right;
				}
		}
		return null;
	}
	
	/**
	 * @param the Key
	 * A utility function to search the courses
	 * @return the Courses
	 */
	String keyValue(int key) {
		node temp = root1;
		while (temp != null) {
				if ((temp.key) == key) {
					return temp.value;
				} else if (temp.key > key) {
					temp = temp.left;
				} else if (temp.key < key) {
					temp = temp.right;
				}
		}
		return null;
	}
			
	
}
