package studentCoursesBackup.util;
	
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.Vector;
import java.util.List;
//import racingDrivers.driverStates.RaceContext;
import studentCoursesBackup.util.MyLogger.DebugLevel;
import studentCoursesBackup.util.MyLogger;


public class Results implements FileDisplayInterface, StdoutDisplayInterface {

	/**Declaring a data structure 
	**/
	//RaceContext race = new RaceContext();
	private List<String> resultList=new Vector<String>();
	
	/**
	Declaring an empty String to store the result got from test file
	**/
	String res = "";



	/**
	* @param the string which needs to be stored
	* Store the result in the list
	* @return nothing
	*/
	public void storeNewResult(String res) {
		resultList.add(res);
		//writeToStdout(res);
	}
	
	
	/**
	* @param the string which needs to be printed
	* Directly print to command line
	* @return nothing
	*/
	public void writeToStdout(String s) {
		System.out.println(s + " Hello");
	}
	
	
	/**
	* @param the string which needs to be printed
	* It will call buffered reader and write it to the output file
	* @return nothing
	*/
	public void writeToFile(String s) 
	{
		//int numberofDrivers = race.getNumber();
		int counter = 0;
		/* Writing to a file using BufferedWriter in Java*/
        try {
			MyLogger.writeMessage ("Output File Opened Here",DebugLevel.OUTPUTFILEOPERATION);
            FileWriter writer = new FileWriter(s);
            BufferedWriter bwr = new BufferedWriter(writer);
            for(String st : resultList)
			{	
				bwr.write(st);
				bwr.write(" ");
				counter++;
				//if(counter==numberofDrivers){
					bwr.newLine();
					bwr.write("\r\n");
					//counter=0;
				//}
			}
            bwr.close(); 
			MyLogger.writeMessage ("Output File closed Here",DebugLevel.OUTPUTFILEOPERATION);
			MyLogger.writeMessage ("Output File released Here",DebugLevel.RELEASE);
        } 
		catch (Exception ioe) {
            System.out.println("Invalid");
        }
		
	}
}
