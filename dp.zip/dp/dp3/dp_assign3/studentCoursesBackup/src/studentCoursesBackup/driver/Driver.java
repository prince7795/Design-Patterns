package studentCoursesBackup.driver;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.io.*;
import studentCoursesBackup.util.FileProcessor;
import studentCoursesBackup.util.Results;
import studentCoursesBackup.util.MyLogger;
import studentCoursesBackup.util.TreeBuilder;


public class Driver {
	public static void main(String[] args) throws FileNotFoundException {

		/*
		 * As the build.xml specifies the arguments as argX, in case the
		 * argument value is not given java takes the default value specified in
		 * build.xml. To avoid that, below condition is used
		 */
		
			if (args.length != 6) {

				System.err.println("Error: You need to give 3 arguements.");
				System.exit(0);
			}
			
			if (args[0].equals("${arg0}") || args[1].equals("${arg1}") || args[2].equals("${arg2}") || args[3].equals("${arg3}") 
				|| args[4].equals("${arg4}") || args[5].equals("${arg5}")) {

				System.err.println("Error: Incorrect Arguements Passed");
				System.exit(0);
			}
			
			
			System.out.println("Hello World! Lets get started with the assignment");	
		
		
		/*Debugging*/
		
		int debugValue = Integer.parseInt(args[5]);
		//System.out.println(debugValue);
		
		
		MyLogger.setDebugValue(debugValue);
		//m1.setDebugValue(
		
		
		
		/*
		* Object creation
		*/
		Results r1 = new Results();
		Results r2 = new Results();
		Results r3 = new Results();
		
		/*
		* File Reading done here
		*/
		
		FileProcessor finput = new FileProcessor();
		FileProcessor fdelete = new FileProcessor();
		finput.initializeFile(args[0]);
		fdelete.initializeFile(args[1]);
		
		TreeBuilder original = new TreeBuilder();
		TreeBuilder back1 = new TreeBuilder();
		TreeBuilder back2 = new TreeBuilder();
		original.getData(finput,fdelete,r1);	

		ArrayList<TreeBuilder> treeList=new ArrayList<TreeBuilder>();
		treeList.add(original);
		treeList.add(back1);
		treeList.add(back2);
		System.out.println();
		original.printNodes1(r1,r2,r3);
		r1.writeToFile(args[2]);
		//original.printNodes2(r2);
		r2.writeToFile(args[3]);
		//original.printNodes3(r3);
		r3.writeToFile(args[4]);
	
	}
}


