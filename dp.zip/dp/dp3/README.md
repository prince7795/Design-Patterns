# CSX42: Assignment 3
## Name: Prince Rajaram Singh	
### BNumber: B00767056

-----------------------------------------------------------------------
-----------------------------------------------------------------------


Following are the commands and the instructions to run ANT on your project.
#### Note: build.xml is present in studentCoursesBackup/src folder.

-----------------------------------------------------------------------
## Instruction to clean:

####Command: ant -buildfile studentCoursesBackup/src/build.xml clean

Description: It cleans up all the .class files that were generated when you
compiled your code.

-----------------------------------------------------------------------
## Instruction to compile:

####Command: ant -buildfile studentCoursesBackup/src/build.xml all

Description: Compiles your code and generates .class files inside the BUILD folder.

-----------------------------------------------------------------------
## Instruction to run:

####Command: ant -buildfile studentCoursesBackup/src/build.xml run -Darg0=<input_file.txt> -Darg1=<delete.txt> -Darg2=<output1.txt>  -Darg3=<output2.txt>  -Darg4=<output3.txt>  -Darg5=<debugvalue>

Note: Arguments accept the absolute path of the files.


-----------------------------------------------------------------------
## Description:

Implemented a courseBackup system which register students BNumber to different courses. In this project, the input is passed using a input.txt file
and it generates a tree structure(Binary Search Tree in this case). There is also a delete.txt file which will search for that Bnumber and deregister
the student from that course.
The project also clones two backup trees from the original tree.

I used Binary Search Tree and implemented it and took help from geeksforgeeks.
Citation : https://www.geeksforgeeks.org/binary-search-tree-set-1-search-and-insertion/

Also implemented Observer Pattern and took help from geeksforgeeks for it.
Citation : https://www.geeksforgeeks.org/observer-pattern-set-2-implementation/

Binary Search Tree stores the root first and then arranges the other node to its left or right. It is easy to implement and its operation 
insert, delete and search.
Time complexity of Insert Operation: O(height)
Time complexity of Delete Operation: O(height)
Time complexity of Search Operation: O(height)
where h is the height of the tree, height is log(number of nodes) in BST.

Since most of the operation in BST are fast, I decided to use BST in this implementaion.

-----------------------------------------------------------------------
### Academic Honesty statement:
-----------------------------------------------------------------------

"I have done this assignment completely on my own. I have not copied
it, nor have I given my solution to anyone else. I understand that if
I am involved in plagiarism or cheating an official form will be
submitted to the Academic Honesty Committee of the Watson School to
determine the action that needs to be taken. "

Date: 07/09/2019


