package troubleShootSearch.iostructure;

import troubleShootSearch.util.Results;
import troubleShootSearch.util.MyLogger.DebugLevel;
import troubleShootSearch.util.MyLogger;
import troubleShootSearch.util.FileProcessor;
import troubleShootSearch.iostructure.datastructure;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;


public class FileReading {
		private FileProcessor finput1;
		private FileProcessor finput2;
		private FileProcessor finput3;
		private FileProcessor finput4;
		private FileProcessor finput5;
		private FileProcessor finput6;
		private ArrayList<String> inputArr1 = new ArrayList<String>();
		private ArrayList<String> productArr1 = new ArrayList<String>();
		private ArrayList<String> productArr2 = new ArrayList<String>();
		private ArrayList<String> productArr3 = new ArrayList<String>();
		private ArrayList<String> productArr4 = new ArrayList<String>();
		HashMap<String, String> hm = new HashMap<String, String>();
		datastructure ds = new datastructure();
	
		public FileReading(FileProcessor fp1, FileProcessor fp2,FileProcessor fp3, FileProcessor fp4,FileProcessor fp5, FileProcessor fp6){
			MyLogger.writeMessage ("FileReading Constructor called",DebugLevel.CONSTRUCTOR);
			finput1=fp1;
			finput2=fp2;
			finput3=fp3;
			finput4=fp4;
			finput5=fp5;
			finput6=fp6;
		}
	
		/**
		* @param nothing
		* It will call getData method from datastructure class and create a arrayList
		* @return inputArr1
		*/
		public ArrayList<String> inputSearch(){
			inputArr1 = ds.getData1(finput1);
			return inputArr1;
		}
		
		/**
		* @param nothing
		* It will call getData method from datastructure class and create a HashMap
		* @return hm
		*/
		public HashMap<String, String> synonymRead(){
			hm = ds.getData2(finput2);
			return hm;
		}
		
		
		/**
		* @param nothing
		* It will call getData method from datastructure class and create a arrayList
		* @return productArr1
		*/
		public ArrayList<String> createProduct1Arr(){
			productArr1 = ds.getData1(finput3);
			return productArr1;
		}
		
		/**
		* @param nothing
		* It will call getData method from datastructure class and create a arrayList
		* @return productArr2
		*/
		public ArrayList<String> createProduct2Arr(){
			productArr2 = ds.getData1(finput4);
			return productArr2;
		}
		
		/**
		* @param nothing
		* It will call getData method from datastructure class and create a arrayList
		* @return productArr3
		*/
		public ArrayList<String> createProduct3Arr(){
			productArr3 = ds.getData1(finput5);
			return productArr3;
		}
		
		/**
		* @param nothing
		* It will call getData method from datastructure class and create a arrayList
		* @return productArr4
		*/
		public ArrayList<String> createProduct4Arr(){
			productArr4 = ds.getData1(finput6);
			return productArr4;
		}

		
}