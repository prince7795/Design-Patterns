package troubleShootSearch.iostructure;

import troubleShootSearch.util.Results;
import java.util.List;
import java.util.ArrayList;
import troubleShootSearch.util.MyLogger.DebugLevel;
import troubleShootSearch.util.MyLogger;
import troubleShootSearch.util.FileProcessor;	
import java.util.HashMap;

	
public class datastructure{	
	
	
	/**
	* @param finput1: get the FileProcessor object from Driver.java
	* Store the data got from read line into arrays 
	* return arr1: array is returned
	*/
	public ArrayList<String> getData1(FileProcessor finput1){
		
		/*
		* Input File Reading done here
		*/
		ArrayList<String> arr1 = new ArrayList<String>();
		String myString="";
		while((myString = finput1.readLine()) != null){
				arr1.add(myString);
			}	
		return arr1;	
	}
	
	
	/**
	* @param finput1: get the FileProcessor object from Driver.java
	* Store the data got from read line into arrays 
	* return arr1: array is returned
	*/
	public HashMap<String,String> getData2(FileProcessor finput1){
		
		/*
		* Input File Reading done here
		*/
		HashMap<String, String> hm = new HashMap<String, String>();
		String myString="";
		while((myString = finput1.readLine()) != null){
				//arr1.add(myString);
				String parts[] = myString.split(":");
				hm.put(parts[0],parts[1]);
			}
			
		return hm;
		
	}
	
	
	
}