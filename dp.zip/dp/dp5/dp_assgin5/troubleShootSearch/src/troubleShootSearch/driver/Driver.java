package troubleShootSearch.driver;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.io.*;
import troubleShootSearch.util.FileProcessor;
import troubleShootSearch.util.Results;
import troubleShootSearch.util.MyLogger;
import troubleShootSearch.util.MyLogger.DebugLevel;
import troubleShootSearch.iostructure.FileReading;
import troubleShootSearch.pattern.ExactSearch;
import troubleShootSearch.pattern.SemanticSearch;
import troubleShootSearch.pattern.NaiveSearch;
import troubleShootSearch.pattern.dSeaGateA;
import troubleShootSearch.pattern.dSeaGateB;
import troubleShootSearch.pattern.dSeaGateC;
import troubleShootSearch.pattern.dSeaGateD;
import troubleShootSearch.pattern.dSeaGateI;
import java.util.HashMap;


public class Driver {
	public static void main(String[] args) throws FileNotFoundException {

		/*
		 * As the build.xml specifies the arguments as argX, in case the
		 * argument value is not given java takes the default value specified in
		 * build.xml. To avoid that, below condition is used
		 */
		
		if (args.length != 8 || args[0].equals("${arg0}") || args[1].equals("${arg1}") || args[2].equals("${arg2}") || args[3].equals("${arg3}") 
			|| args[4].equals("${arg4}") || args[5].equals("${arg5}") || args[6].equals("${arg6}") || args[7].equals("${arg7}")) {

				System.err.println("Error: You need to pass 8 arguements.");
				System.err.println("Error: Incorrect Arguements Passed");
				System.exit(0);
		}
				
		System.out.println("TroubleShootSearch");
		String outputFile=null;	
		outputFile = args[6];
		
		/* ArrayList and Hashmap*/
		ArrayList<String> Arr1 = new ArrayList<String>();
		ArrayList<String> pArr1 = new ArrayList<String>();
		ArrayList<String> pArr2 = new ArrayList<String>();
		ArrayList<String> pArr3 = new ArrayList<String>();
		ArrayList<String> pArr4 = new ArrayList<String>();
		HashMap<String, String> synonymMap = new HashMap<String, String>();
		
		/*Debugging*/
		//MyLogger ml = new MyLogger();
		int debugValue = Integer.parseInt(args[7]);
		System.out.println("The DebugValue is: "+debugValue);
		MyLogger.setDebugValue(debugValue);
		
		/*
		* Object creation
		*/
		try{
			
			Results res = new Results();
			FileProcessor fp1 = new FileProcessor();
			FileProcessor fp2 = new FileProcessor();
			FileProcessor fp3 = new FileProcessor();
			FileProcessor fp4 = new FileProcessor();
			FileProcessor fp5 = new FileProcessor();
			FileProcessor fp6 = new FileProcessor();
			fp1.initializeFile(args[0]);
			fp2.initializeFile(args[1]);
			fp3.initializeFile(args[2]);
			fp4.initializeFile(args[3]);
			fp5.initializeFile(args[4]);
			fp6.initializeFile(args[5]);
					
			FileReading fr = new FileReading(fp1,fp2,fp3,fp4,fp5,fp6);
			Arr1 = fr.inputSearch();
			pArr1 = fr.createProduct1Arr();
			pArr2 = fr.createProduct2Arr();
			pArr3 = fr.createProduct3Arr();
			pArr4 = fr.createProduct4Arr();
			synonymMap = fr.synonymRead();
			
			/* Visitor Pattern */
			
			dSeaGateI[] list = {new dSeaGateA(pArr1), new dSeaGateB(pArr2), new dSeaGateC(pArr3),new dSeaGateD(pArr4)};
			ExactSearch es = new ExactSearch(Arr1,res);
			NaiveSearch ns = new NaiveSearch(Arr1,res);
			SemanticSearch ss = new SemanticSearch(Arr1,synonymMap,res);
			for (dSeaGateI element : list) {
				element.accept(es);
				element.accept(ns);
				element.accept(ss);
			}
			res.writeToFile(outputFile);
			if(debugValue==0){
				MyLogger.writeMessage ("No output should be printed for this debugValue",DebugLevel.NOOUTPUT);
			}
			else{
				res.writeToStdout();
			}
			}
		catch(Exception e){
				e.printStackTrace();
				System.exit(0);
		}
		finally{}
	}
}


