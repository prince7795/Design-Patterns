package troubleShootSearch.util;

public interface StdoutDisplayInterface {

	public void writeToStdout();
}