package troubleShootSearch.util;

public interface FileDisplayInterface {
	/* 
	*Used to write to the command line
	*/
	public void writeToFile(String s);
}