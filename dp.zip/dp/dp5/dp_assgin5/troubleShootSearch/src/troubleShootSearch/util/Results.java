package troubleShootSearch.util;
	
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import troubleShootSearch.util.MyLogger.DebugLevel;
import troubleShootSearch.util.MyLogger;


public class Results implements FileDisplayInterface, StdoutDisplayInterface {

	/**Declaring a data structure 
	**/
	private List<String> resultList=new Vector<String>();
	
	/**
	Declaring an empty String to store the result got from test file
	**/
	String res = "";



	/**
	* @param the string which needs to be stored
	* Store the result in the list
	* @return nothing
	*/
	public void storeNewResult(String res) {
		resultList.add(res);
	}
	
	
	/**
	* @param nothing
	* Directly print to command line
	* @return nothing
	*/
	public void writeToStdout() {
		 for(String st : resultList){	
				System.out.println(st);
				System.out.println();
			}
	}
	
	
	/**
	* @param the output file name which needs to be created
	* It will call buffered reader and write it to the output file
	* @return nothing
	*/
	public void writeToFile(String s) 
	{
		int counter = 0;
		/* Writing to a file using BufferedWriter in Java*/
        try {
            FileWriter writer = new FileWriter(s);
            BufferedWriter bwr = new BufferedWriter(writer);
            for(String st : resultList)
			{	
				bwr.write(st);
				bwr.newLine();
				bwr.write("\r\n");
				counter++;	
			}
            bwr.close(); 
        } 
		catch (Exception ioe) {
            System.out.println("Invalid");
        }
		
	}
}
