package troubleShootSearch.pattern;

import java.util.ArrayList;
import troubleShootSearch.util.Results;
import troubleShootSearch.util.MyLogger.DebugLevel;
import troubleShootSearch.util.MyLogger;
 
 
public class NaiveSearch implements Visitor {
	
	
	private ArrayList<String> userInputArr = new ArrayList<String>();
	private ArrayList<String> productArr1 = new ArrayList<String>();
	private ArrayList<String> productArr2 = new ArrayList<String>();
	private ArrayList<String> productArr3 = new ArrayList<String>();
	private ArrayList<String> productArr4 = new ArrayList<String>();
	private Results res;
    
	public NaiveSearch(ArrayList<String> arr, Results r)
	{ 
        this.userInputArr=arr; 
		res = r;
		MyLogger.writeMessage ("NaiveSearch Constructor called",DebugLevel.CONSTRUCTOR);
    }
	
	
    public void visit(dSeaGateA a) {
        //System.out.println("NaiveSearch on " + a.getSearchA());
		this.productArr1 = a.getProductArr1();
		for(int i=0;i<userInputArr.size();i++){
				String parts[] = userInputArr.get(i).split(" ");
				for(int j=0;j<productArr1.size();j++){
					int flag=0;
					String parts2[] = productArr1.get(j).split(" ");
					for(String s:parts2){
						if( s.compareTo(parts[0]) == 0 ){
							flag=1;
						}
					}
					if((productArr1.get(j).contains(parts[0])) && flag==0){
						//System.out.println(productArr1.get(j));
						res.storeNewResult("NaiveSearch matched on Product A:"+productArr1.get(j));
					}
				}
		}
		MyLogger.writeMessage ("Product dSeaGateA visited from here",DebugLevel.VISITED);
		//System.out.println();
    }

    public void visit(dSeaGateB b) {
        //System.out.println("NaiveSearch on " + b.getSearchB());
		this.productArr2 = b.getProductArr2();
		for(int i=0;i<userInputArr.size();i++){
				String parts[] = userInputArr.get(i).split(" ");
				for(int j=0;j<productArr2.size();j++){
					int flag=0;
					String parts2[] = productArr2.get(j).split(" ");
					for(String s:parts2){
						if( s.compareTo(parts[0]) == 0 ){
							flag=1;
						}
					}
					//System.out.println(flag);
					if(productArr2.get(j).contains(parts[0]) && flag==0 ){
						//System.out.println(productArr2.get(j));
						res.storeNewResult("NaiveSearch matched on Product B:"+productArr2.get(j));
					}
				}
		}
		MyLogger.writeMessage ("Product dSeaGateB visited from here",DebugLevel.VISITED);
		//System.out.println();
    }

    public void visit(dSeaGateC c) {
        //System.out.println( "NaiveSearch on " + c.getSearchC());
		this.productArr3 = c.getProductArr3();
		for(int i=0;i<userInputArr.size();i++){
				String parts[] = userInputArr.get(i).split(" ");
				for(int j=0;j<productArr3.size();j++){
					int flag=0;
					String parts2[] = productArr3.get(j).split(" ");
					for(String s:parts2){
						if( s.compareTo(parts[0]) == 0 ){
							flag=1;
						}
					}
					if(productArr3.get(j).contains(parts[0]) && flag==0 ){
						//System.out.println(productArr3.get(j));
						res.storeNewResult("NaiveSearch matched on Product C:"+productArr3.get(j));
					}
				}
		}
		MyLogger.writeMessage ("Product dSeaGateC visited from here",DebugLevel.VISITED);
		//System.out.println();
    }
	
	public void visit(dSeaGateD d) {
        //System.out.println( "NaiveSearch on " + d.getSearchD());
		this.productArr4 = d.getProductArr4();
		for(int i=0;i<userInputArr.size();i++){
				String parts[] = userInputArr.get(i).split(" ");
				for(int j=0;j<productArr4.size();j++){
					int flag=0;
					String parts2[] = productArr4.get(j).split(" ");
					for(String s:parts2){
						if( s.compareTo(parts[0]) == 0 ){
							flag=1;
						}
					}
					if(productArr4.get(j).contains(parts[0]) && flag==0 ){
						//System.out.println(productArr4.get(j));
						res.storeNewResult("NaiveSearch matched on Product D:"+productArr4.get(j));
					}
				}
		}
		MyLogger.writeMessage ("Product dSeaGateD visited from here",DebugLevel.VISITED);
		//System.out.println();
    }
}