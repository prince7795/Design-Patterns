package troubleShootSearch.pattern;

import java.util.ArrayList;
import troubleShootSearch.util.MyLogger.DebugLevel;
import troubleShootSearch.util.MyLogger;

 
public class dSeaGateC implements dSeaGateI {
    
	private ArrayList<String> productArr3 = new ArrayList<String>();
    
	public dSeaGateC(ArrayList<String> arr)
	{ 
		MyLogger.writeMessage ("dSeaGateC Constructor called",DebugLevel.CONSTRUCTOR);
        this.productArr3=arr; 
    } 
	
	
	@Override
	public void   accept( Visitor v ) {
        v.visit( this );
    }

    public String getSearchC() {
        return "Product c";
    }
	
	
	/**
	* @param nothing
	* It will return the ArrayList of this class
	* @return productArr3
	*/
	public ArrayList<String> getProductArr3(){
		return this.productArr3;
	}
	
	
}