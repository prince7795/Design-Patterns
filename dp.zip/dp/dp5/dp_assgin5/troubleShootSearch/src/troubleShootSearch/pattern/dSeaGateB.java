package troubleShootSearch.pattern;

import java.util.ArrayList;
import troubleShootSearch.util.MyLogger.DebugLevel;
import troubleShootSearch.util.MyLogger;


public class dSeaGateB implements dSeaGateI {
    
	private ArrayList<String> productArr2 = new ArrayList<String>();
    
	public dSeaGateB(ArrayList<String> arr)
	{ 
		MyLogger.writeMessage ("dSeaGateB Constructor called",DebugLevel.CONSTRUCTOR);
        this.productArr2=arr; 
    } 
	
	@Override
	public void accept(Visitor v) {
        v.visit(this);
    }

    public String getSearchB() {
        return "Product B";
    }
	
	
	/**
	* @param nothing
	* It will return the ArrayList of this class
	* @return productArr2
	*/
	public ArrayList<String> getProductArr2(){
		return this.productArr2;
	}
}