package troubleShootSearch.pattern;

import java.util.ArrayList;
import troubleShootSearch.util.MyLogger.DebugLevel;
import troubleShootSearch.util.MyLogger;

 
public class dSeaGateA implements dSeaGateI {
	
	public ArrayList<String> productArr1 = new ArrayList<String>();
    
	public dSeaGateA(){}
	
	
	public dSeaGateA(ArrayList<String> arr)
	{ 
		MyLogger.writeMessage ("dSeaGateA Constructor called",DebugLevel.CONSTRUCTOR);
        this.productArr1=arr; 
    } 
	
	@Override
	public void accept(Visitor v) {
        v.visit(this);
    }

    public String getSearchA() {
        return "Product A";
    }
	
	
	/**
	* @param nothing
	* It will return the ArrayList of this class
	* @return productArr1
	*/
	public ArrayList<String> getProductArr1(){
		return this.productArr1;
	}	
}