package troubleShootSearch.pattern;

import java.util.ArrayList;
import troubleShootSearch.util.MyLogger.DebugLevel;
import troubleShootSearch.util.MyLogger;
  
public class dSeaGateD implements dSeaGateI {
    
	private ArrayList<String> productArr4 = new ArrayList<String>();
    
	public dSeaGateD(ArrayList<String> arr)
	{ 
		MyLogger.writeMessage ("dSeaGateD Constructor called",DebugLevel.CONSTRUCTOR);
        this.productArr4=arr; 
    } 
	
	
	@Override
	public void accept(Visitor v) {
        v.visit(this);
    }

    public String getSearchD() {
        return "Product D";
    }
	
	
	/**
	* @param nothing
	* It will return the ArrayList of this class
	* @return productArr4
	*/
	public ArrayList<String> getProductArr4(){
		return this.productArr4;
	}
}