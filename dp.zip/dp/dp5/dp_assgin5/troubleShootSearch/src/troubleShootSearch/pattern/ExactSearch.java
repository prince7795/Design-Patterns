package troubleShootSearch.pattern;

import java.util.ArrayList;
import troubleShootSearch.util.Results;
import troubleShootSearch.util.MyLogger.DebugLevel;
import troubleShootSearch.util.MyLogger;
 
public class ExactSearch implements Visitor {
	
	private ArrayList<String> userInputArr = new ArrayList<String>();
	private ArrayList<String> productArr1 = new ArrayList<String>();
	private ArrayList<String> productArr2 = new ArrayList<String>();
	private ArrayList<String> productArr3 = new ArrayList<String>();
	private ArrayList<String> productArr4 = new ArrayList<String>();
	private Results res;
    
	public ExactSearch(ArrayList<String> arr, Results r)
	{ 
        this.userInputArr=arr; 
		res = r;
		MyLogger.writeMessage ("ExactSearch Constructor called",DebugLevel.CONSTRUCTOR);
    }
	

	@Override
    public void visit(dSeaGateA a) {
       // System.out.println("ExactSearch on " + a.getSearchA());
		//System.out.println("Matching ExactSearch on A");
		this.productArr1 = a.getProductArr1();
		for(int i=0;i<userInputArr.size();i++){
				for(int j=0;j<productArr1.size();j++){
					String parts[] = productArr1.get(j).split(" ");
					for(String k : parts){
						if((userInputArr.get(i).compareTo(k)) == 0 ){
							//System.out.println(productArr1.get(j));
							res.storeNewResult("ExactSearch matched on Product A:"+productArr1.get(j));
						}
		
					}
				}
		}
		MyLogger.writeMessage ("Product dSeaGateA visited from here",DebugLevel.VISITED);
		//System.out.println();
    }
	
	@Override
    public void visit(dSeaGateB b) {
        //System.out.println("ExactSearch on " + b.getSearchB());
		//System.out.println("Matching ExactSearch on B");
		this.productArr2 = b.getProductArr2();
		for(int i=0;i<userInputArr.size();i++){
				for(int j=0;j<productArr2.size();j++){
					String parts[] = productArr2.get(j).split(" ");
					for(String k : parts){
						if((userInputArr.get(i).compareTo(k)) == 0 ){
							//System.out.println(productArr2.get(j));
							res.storeNewResult("ExactSearch matched on Product B:"+productArr2.get(j));
						}
					}
				}
		}
		MyLogger.writeMessage ("Product dSeaGateB visited from here",DebugLevel.VISITED);
		//System.out.println();
    }

	@Override
    public void visit(dSeaGateC c) {
       // System.out.println( "ExactSearch on " + c.getSearchC());
		//System.out.println("Matching ExactSearch on C");
		this.productArr3 = c.getProductArr3();
		for(int i=0;i<userInputArr.size();i++){
				for(int j=0;j<productArr3.size();j++){
					String parts[] = productArr3.get(j).split(" ");
					for(String k : parts){
						if((userInputArr.get(i).compareTo(k)) == 0 ){
							//System.out.println(productArr3.get(j));
							res.storeNewResult("ExactSearch matched on Product C:"+productArr3.get(j));
						}
					}
				}
		}
		MyLogger.writeMessage ("Product dSeaGateC visited from here",DebugLevel.VISITED);
		//System.out.println();
    }
	
	
	
	@Override
	public void visit(dSeaGateD d) {
        //System.out.println( "ExactSearch on " + d.getSearchD());
		//System.out.println("Matching ExactSearch on D");
		this.productArr4 = d.getProductArr4();
		for(int i=0;i<userInputArr.size();i++){
				for(int j=0;j<productArr4.size();j++){
					String parts[] = productArr4.get(j).split(" ");
					for(String k : parts){
						if((userInputArr.get(i).compareTo(k)) == 0 ){
							//System.out.println(productArr4.get(j));
							res.storeNewResult("ExactSearch matched on Product D:"+productArr4.get(j));
						}
					}
				}
		}
		MyLogger.writeMessage ("Product dSeaGateD visited from here",DebugLevel.VISITED);
		//System.out.println();
    }
	
	
	
}