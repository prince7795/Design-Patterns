package troubleShootSearch.pattern;

public interface dSeaGateI {
    void accept(Visitor v);
}
