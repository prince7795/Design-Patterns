package troubleShootSearch.pattern;

import java.util.ArrayList;
import troubleShootSearch.util.Results;
import java.util.HashMap;
import java.util.Map;
import troubleShootSearch.util.MyLogger.DebugLevel;
import troubleShootSearch.util.MyLogger;
 
public class SemanticSearch implements Visitor {
	
	
	private ArrayList<String> userInputArr = new ArrayList<String>();
	private ArrayList<String> productArr1 = new ArrayList<String>();
	private ArrayList<String> productArr2 = new ArrayList<String>();
	private ArrayList<String> productArr3 = new ArrayList<String>();
	private ArrayList<String> productArr4 = new ArrayList<String>();
	private Results res;
	private HashMap<String, String> hm = new HashMap<String, String>();
    
	public SemanticSearch(ArrayList<String> arr,HashMap<String, String> synR, Results r)
	{ 
        this.userInputArr=arr; 
		res = r;
		this.hm = synR;
		MyLogger.writeMessage ("SemanticSearch Constructor called",DebugLevel.CONSTRUCTOR);
    }
	
	@Override
    public void visit(dSeaGateA a) {
        //System.out.println("SemanticSearch on " + a.getSearchA());
		ArrayList<String> prodMatch1 = new ArrayList<String>();
		this.productArr1 = a.getProductArr1();
		for(int i=0;i<userInputArr.size();i++){
				String parts[] = userInputArr.get(i).split(" ");
				for (String key : hm.keySet()) {
				  // System.out.println("key: " + key + " value: " + hm.get(key));
				   if( (parts[parts.length-1].compareTo(key)) == 0 ){
					  prodMatch1.add(hm.get(key));
				   }
				   if( (parts[parts.length-1].compareTo(hm.get(key))) == 0 ){
					  prodMatch1.add(key);
				   }
				}			
				
		}
		
		for(int i=0;i<prodMatch1.size();i++){
				for(int j=0;j<productArr1.size();j++){
					String parts[] = productArr1.get(j).split(" ");
					for(String k : parts){
						if((prodMatch1.get(i).compareTo(k)) == 0 ){
							//System.out.println(productArr1.get(j));
							res.storeNewResult("SemanticSearch matched on Product A:"+productArr1.get(j));
						}
		
					}
				}
		}
		MyLogger.writeMessage ("Product dSeaGateA visited from here",DebugLevel.VISITED);
		//System.out.println();
    }
	
	@Override
    public void visit(dSeaGateB b) {
        //System.out.println("SemanticSearch on " + b.getSearchB());
		ArrayList<String> prodMatch2 = new ArrayList<String>();
		this.productArr2 = b.getProductArr2();
		for(int i=0;i<userInputArr.size();i++){
				String parts[] = userInputArr.get(i).split(" ");
				for (String key : hm.keySet()) {
				  // System.out.println("key: " + key + " value: " + hm.get(key));
				   if( (parts[parts.length-1].compareTo(key)) == 0 ){
					  prodMatch2.add(hm.get(key));
				   }
				   if( (parts[parts.length-1].compareTo(hm.get(key))) == 0 ){
					  prodMatch2.add(key);
				   }
				}			
				
		}
		
		for(int i=0;i<prodMatch2.size();i++){
				for(int j=0;j<productArr2.size();j++){
					String parts[] = productArr2.get(j).split(" ");
					for(String k : parts){
						if((prodMatch2.get(i).compareTo(k)) == 0 ){
							//System.out.println(productArr2.get(j));
							res.storeNewResult("SemanticSearch matched on Product B:"+productArr2.get(j));
						}
		
					}
				}
		}
		MyLogger.writeMessage ("Product dSeaGateB visited from here",DebugLevel.VISITED);
		//System.out.println();
    }
	
	@Override
    public void visit(dSeaGateC c) {
        //System.out.println( "SemanticSearch on " + c.getSearchC());
		ArrayList<String> prodMatch3 = new ArrayList<String>();
		this.productArr3 = c.getProductArr3();
		for(int i=0;i<userInputArr.size();i++){
				String parts[] = userInputArr.get(i).split(" ");
				for (String key : hm.keySet()) {
				  // System.out.println("key: " + key + " value: " + hm.get(key));
				   if( (parts[parts.length-1].compareTo(key)) == 0 ){
					  prodMatch3.add(hm.get(key));
				   }
				   if( (parts[parts.length-1].compareTo(hm.get(key))) == 0 ){
					  prodMatch3.add(key);
				   }
				}			
				
		}
		
		for(int i=0;i<prodMatch3.size();i++){
				for(int j=0;j<productArr3.size();j++){
					String parts[] = productArr3.get(j).split(" ");
					for(String k : parts){
						if((prodMatch3.get(i).compareTo(k)) == 0 ){
							//System.out.println(productArr3.get(j));
							res.storeNewResult("SemanticSearch matched on Product C:"+productArr3.get(j));
						}
		
					}
				}
		}
		MyLogger.writeMessage ("Product dSeaGateC visited from here",DebugLevel.VISITED);
		//System.out.println();
    }
	
	@Override
	public void visit(dSeaGateD d) {
        //System.out.println( "SemanticSearch on " + d.getSearchD());
		ArrayList<String> prodMatch4 = new ArrayList<String>();
		this.productArr4 = d.getProductArr4();
		for(int i=0;i<userInputArr.size();i++){
				String parts[] = userInputArr.get(i).split(" ");
				for (String key : hm.keySet()) {
				  // System.out.println("key: " + key + " value: " + hm.get(key));
				   if( (parts[parts.length-1].compareTo(key)) == 0 ){
					  prodMatch4.add(hm.get(key));
				   }
				   if( (parts[parts.length-1].compareTo(hm.get(key))) == 0 ){
					  prodMatch4.add(key);
				   }
				}			
				
		}
		
		for(int i=0;i<prodMatch4.size();i++){
				for(int j=0;j<productArr4.size();j++){
					String parts[] = productArr4.get(j).split(" ");
					for(String k : parts){
						if((prodMatch4.get(i).compareTo(k)) == 0 ){
							//System.out.println(productArr4.get(j));
							res.storeNewResult("SemanticSearch matched on Product D:"+productArr4.get(j));
						}
		
					}
				}
		}
		MyLogger.writeMessage ("Product dSeaGateD visited from here",DebugLevel.VISITED);
		//System.out.println();
    }
}