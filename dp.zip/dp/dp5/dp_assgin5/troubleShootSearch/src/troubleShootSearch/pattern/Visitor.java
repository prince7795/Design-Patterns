package troubleShootSearch.pattern;

public interface Visitor {
    void visit(dSeaGateA a);
    void visit(dSeaGateB b);
    void visit(dSeaGateC c);
	void visit(dSeaGateD d);
}