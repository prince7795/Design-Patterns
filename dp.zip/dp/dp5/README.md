# CSX42: Assignment 5
## Name: Prince Rajaram Singh
### BNumber: B00767056

-----------------------------------------------------------------------
-----------------------------------------------------------------------


Following are the commands and the instructions to run ANT on your project.
#### Note: build.xml is present in troubleShootSearch/src folder.

-----------------------------------------------------------------------
## Instruction to clean:

####Command: 
ant -buildfile troubleShootSearch/src/build.xml clean

Description: It cleans up all the .class files that were generated when you
compiled your code.

-----------------------------------------------------------------------
## Instruction to compile:

####Command: ant -buildfile troubleShootSearch/src/build.xml all

Description: Compiles your code and generates .class files inside the BUILD folder.

-----------------------------------------------------------------------
## Instruction to run:

####Command: 

ant -buildfile troubleShootSearch/src/build.xml run -Darg0=<userInput> -Darg1=<SynonymFile> -Darg2=<ProductA> -Darg3=<ProductB> 
-Darg4=<ProductC> -Darg5=<ProductD> -Darg6=<OutputFile> -Darg7=<DebugValue>"

####Example according to my files:

ant -buildfile troubleShootSearch/src/build.xml run -Darg0="input.txt" -Darg1="synonym.txt" -Darg2="product1.txt" -Darg3="product2.txt" 
-Darg4="product3.txt" -Darg5="product4.txt" -Darg6="output.txt" -Darg7=2"


-----------------------------------------------------------------------
## Description:
This project implements a troubleShoot Search for a hardDisk company. There are 27 user searches among which 24 entries will be matched
with either of 3 searches i.e ExactSearch,Naive Stemming Search or SemanticSearch. In this search implementation, 8 entries from userInput 
are matched using ExactSearch, 8 entries using NaiveSearch and 8 entries using SemanticSearch. All these 24 entries which are matched with
24 sentences are spread across 4 products. All these 4 products have different ArrayList which contains sentences, these sentences are read
from 4 different files.

Implementation of Visitor Pattern:
This project used Visitors Pattern implementation. There is dSeaGateI interface which has accept() method with arguement as Visitors object.
4 products each have a different class which implements dSeaGateI interface. All these class has accept method which overrides the accept() in
interface. This class files also have getProductArr() method which will return its associated arraylist. 
Then we have visitor interface which have 4 visit() method for each of the above 4 classes and which take its objects as its parameter. The 
3 search classes implements this interface and their visit() method overrides the visit() in the interface. All the logic for respective 
searches are return in this visit() method.

Justification for DataStructure used:
	ArrayList: I used ArrayList for almost all operations. ArrayList provides us with methods which are easy to work with. Also while 
initializing a ArrayList we do not need to specify size before working on it, we can dynamically add or remove elements
from ArrayList as per as our requirement.
	HashMap: I used HashMap to store the values from the Synonym.txt as we wanted the the entries to be stored as key-value pair. Also the
getKey() method of HashMap has time complexity of O(1). 

I created a seperate package named iostructure which contains datastructure class and FileReading class which will call readline method
from FileProcessor and create different arrayLists required for running of this project.

Citation:
For implementing visitor pattern I took help from following site.
	https://sourcemaking.com/design_patterns/visitor/java/1
	
MyLogger Scheme:
	  DEBUG_VALUE=4 Print to stdout everytime a constructor is called
      DEBUG_VALUE=3 Print to stdout everytime the inputFile operation is done
      DEBUG_VALUE=2 Print to stdout everytime a class is visited(Visitor Pattern)
      DEBUG_VALUE=1 Print to stdout the search Result 
      DEBUG_VALUE=0 No output should be printed from the application to stdout.
	

-----------------------------------------------------------------------
### Academic Honesty statement:
-----------------------------------------------------------------------

"I have done this assignment completely on my own. I have not copied
it, nor have I given my solution to anyone else. I understand that if
I am involved in plagiarism or cheating I will have to sign an
official form that I have cheated and that this form will be stored in
my official university record. I also understand that I will receive a
grade of 0 for the involved assignment for my first offense and that I
will receive a grade of F for the course for any additional
offense."

Date: 8-5-2019


