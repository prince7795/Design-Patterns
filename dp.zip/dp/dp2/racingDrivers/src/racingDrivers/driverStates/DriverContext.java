package racingDrivers.driverStates;

import java.lang.Math; 
import racingDrivers.driverStates.Leading;
import racingDrivers.driverStates.Losing;
import racingDrivers.driverStates.Holding_on;
import racingDrivers.util.Results;
import racingDrivers.util.MyLogger.DebugLevel;
import racingDrivers.util.MyLogger;
//import java.util.Arrays;

 
 public class DriverContext implements DriverContextI{
	 	 
	Leading l = new Leading();
	Losing lo = new Losing();
	Holding_on h = new Holding_on();
	DriverState ds = new DriverState();
      
	 
	 int samePositionFlag=0;;
	 
	/**
	* @param the value whose position should be returned and the sorted array
	* Store the data got from read line into arrays 
	* @return Will return driverposition as integer value
	*/
	 public int driverPosition(double value, double[] array3){
			
			int low = 0, high = array3.length-1; 						
        	while (low <= high) { 							
            int mid = low + (high - low) / 2; 
  
            if (array3[mid] == value){
                return 1+mid; 
			}
  
            /* If value greater, ignore left half */
            if (array3[mid] > value) 
                low = mid + 1; 
  
            /*If value is smaller, ignore right half */
            else
                high = mid - 1; 
        } 
  
        /* if we reach here, then element was 
        * not present 
         */
        return -1;
		 
	 }
	 
	 
	/**
	* @param the array to be sorted
	* Sort the array is descending order using bubbleSort
	*/
	 public void bubbleSort(double[] intArray) {	
		int n = intArray.length;
		double temp = 0;
		
		for(int i=0; i < n; i++){
			for(int j=1; j < (n-i); j++){
				
				if(intArray[j-1] < intArray[j]){
					//swap the elements!
					temp = intArray[j-1];
					intArray[j-1] = intArray[j];
					intArray[j] = temp;
				}
				
			}
		}
	
	}
	
	
	
	/**
	* @param the array on which we will iterate
	* All the state calculations will be done here
	* @return nothing
	*/
	public void findState(double[] ary, Results r){
		int num3=ary.length;
		double[] aryPosition = new double[num3];
		
		for(int i=0;i<num3;i++)
		  aryPosition[i] = ary[i];
	 
	  /*Sorting the temp Array*/
	  bubbleSort(aryPosition);	
	  
	  int position;
	  double value;
	  /* Iterate through Array*/
		for(int i=0;i<num3;i++){
			for(int k=0;k<num3;k++){
				if(ary[i]==ary[k] && i!=k)
					samePositionFlag=1;	
			}
			
				
		 
		 value = (Double) ary[i];
		 position = driverPosition(value,aryPosition);
		 if(samePositionFlag==1){
			  lo.doAction(ds,r);

			  //System.out.println(ds.getState().toString());
		 }
		 else{
			 if(position < ( 0.3 * num3 ) ){
				 l.doAction(ds,r);
			     //System.out.println(ds.getState().toString());
			 }
			 else if(Math.round( 0.3 * num3 ) <= position && position < Math.round( 0.7 * num3 )){
				 h.doAction(ds,r);
			     //System.out.println(ds.getState().toString());
			 }
			 else if(position >= Math.round( 0.7 * num3)){
				 lo.doAction(ds,r);
			     //System.out.println(ds.getState().toString());
			 }
		 }
		 MyLogger.writeMessage ("State Changed",DebugLevel.STATECHANGED);
			 samePositionFlag=0;
		}
	  System.out.println();	
	}
   

}