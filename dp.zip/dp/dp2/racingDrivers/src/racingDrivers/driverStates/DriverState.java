package racingDrivers.driverStates;

import racingDrivers.util.MyLogger.DebugLevel;
import racingDrivers.util.MyLogger;

public class DriverState {
   private DriverStateI state;

   public DriverState(){
	  MyLogger.writeMessage("DriverState Constructor called",DebugLevel.CONSTRUCTOR);
      state = null;
   }

   public void setState(DriverStateI state){
      this.state = state;		
   }

   public DriverStateI getState(){
      return state;
   }
}