package racingDrivers.driverStates;
import racingDrivers.util.Results;

public class Losing implements DriverStateI {
	
	/**
	* @param The DriverState object and the object of result for printing
	* @return nothing
	*/
	public void doAction(DriverState ds,Results r) {
		//System.out.println("Losing");
		r.storeNewResult("RECKLESS");
		ds.setState(this);	
   }
   
   public String toString(){
      return "RECKLESS";
   }
   
}