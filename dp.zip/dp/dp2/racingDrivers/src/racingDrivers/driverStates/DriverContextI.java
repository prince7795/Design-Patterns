package racingDrivers.driverStates;
import racingDrivers.util.Results;
 
 public interface DriverContextI {
	 
	    public int driverPosition(double value, double[] array3);
		
		public void bubbleSort(double[] intArray);
		
		public void findState(double[] ary, Results r);

	 
	 
 }