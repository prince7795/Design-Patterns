package racingDrivers.driverStates;

import racingDrivers.util.FileProcessor;
import racingDrivers.driver.Driver;
import racingDrivers.driverStates.Leading;
import racingDrivers.driverStates.DriverContext;
import racingDrivers.util.Results;
import racingDrivers.util.MyLogger.DebugLevel;
import racingDrivers.util.MyLogger;
 
 public class RaceContext {
	 
	 static int num2 = 0;
	
	/**
	* @param get the FileProcessor object from Driver.java
	* Store the data got from read line into arrays            
	*/
	public void getData(FileProcessor fp,Results r){
		
		DriverContext dc=new DriverContext();
		/*
		* File Reading done here
		*/
		String tempNum2=fp.readLine();
		num2=Integer.parseInt(tempNum2);
		
		System.out.println("Input from Fileprocessor "+num2);
		//int x = getNumber();
		String myString;
		double[] ary = new double[num2];
		double[] aryPosition = new double[num2];
		
		for(int i=0;i<num2;i++)
			ary[i]=0;
		
		while((myString = fp.readLine()) != null){
			String[] tokens = myString.split(" ");
			

			int j = 0;
			for (String token : tokens){
				ary[j] = ary[j] + Double.parseDouble(token); 
				j++;
			}
			dc.findState(ary,r);
			
		} 
		MyLogger.writeMessage ("Input File closed Here",DebugLevel.INPUTFILEOPERATION);
		MyLogger.writeMessage ("Input File released Here",DebugLevel.RELEASE);
	}
	
	
	
	/**
	* @param nothing
	* @returns the number of drivers            
	*/
	public int getNumber(){
		return this.num2;
 }
 
 }