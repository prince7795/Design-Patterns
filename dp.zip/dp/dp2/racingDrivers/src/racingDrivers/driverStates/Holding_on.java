package racingDrivers.driverStates;
import racingDrivers.util.Results;

public class Holding_on implements DriverStateI {
	
	/**
	* @param The DriverState object and the object of result for printing
	* @return nothing
	*/
	public void doAction(DriverState ds, Results r) {
		//System.out.println("Leading");
		r.storeNewResult("CALCULATIVE");
		ds.setState(this);	
   }
   
   public String toString(){
      return "CALCULATIVE";
   }
   
   
}