package racingDrivers.driverStates;
import racingDrivers.util.Results;

public class Leading implements DriverStateI {
		
		/**
		* @param The DriverState object and the object of result for printing
		* @return nothing
		*/
		public void doAction(DriverState ds,Results r) {
		//System.out.println("Leading");
		r.storeNewResult("CONFIDENT");
		ds.setState(this);	
   }
   
   public String toString(){
      return "CONFIDENT";
   }
   
   
}