package racingDrivers.driverStates;
import racingDrivers.util.Results;
 
 public interface DriverStateI {
	 public void doAction(DriverState ds,Results r);
 }