package racingDrivers.util;

public interface StdoutDisplayInterface {

	public void writeToStdout(String s);
}