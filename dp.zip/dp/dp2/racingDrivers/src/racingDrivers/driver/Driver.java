package racingDrivers.driver;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.*;
import racingDrivers.util.FileProcessor;
import racingDrivers.driverStates.RaceContext;
import racingDrivers.driverStates.Leading;
import racingDrivers.util.Results;
import racingDrivers.util.MyLogger;


public class Driver {
	public static void main(String[] args) throws FileNotFoundException {

		/*
		 * As the build.xml specifies the arguments as argX, in case the
		 * argument value is not given java takes the default value specified in
		 * build.xml. To avoid that, below condition is used
		 */
		
			if (args.length != 3) {

				System.err.println("Error: You need to give 3 arguements.");
				System.exit(0);
			}
			
			if (args[0].equals("${arg0}") || args[1].equals("${arg1}") || args[2].equals("${arg2}")) {

				System.err.println("Error: Incorrect Arguements Passed");
				System.exit(0);
			}
			
			
			System.out.println("Hello World! Lets get started with the assignment");	
		
		
		/*Debugging*/
		
		int debugValue = Integer.parseInt(args[2]);
		//System.out.println(debugValue);
		
		
		MyLogger.setDebugValue(debugValue);
		//m1.setDebugValue(
		
		
		
		/*
		* Object creation
		*/
		Results r = new Results();
		
		/*
		* File Reading done here
		*/
		
		FileProcessor f = new FileProcessor();
		f.initializeFile(args[0]);
		
		RaceContext rc = new RaceContext();
		rc.getData(f,r);		
		r.writeToFile(args[1]);
	
	}
}


