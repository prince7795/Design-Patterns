# CSX42: Assignment 2
## Name: Prince Rajaram Singh
### BNumber: B00767056

-----------------------------------------------------------------------
-----------------------------------------------------------------------


Following are the commands and the instructions to run ANT on your project.
#### Note: build.xml is present in racingDrivers/src folder.

-----------------------------------------------------------------------
## Instruction to clean:

####Command: ant -buildfile racingDrivers/src/build.xml clean

Description: It cleans up all the .class files that were generated when you
compiled your code.

-----------------------------------------------------------------------
## Instruction to compile:

####Command: ant -buildfile racingDrivers/src/build.xml all

Description: Compiles your code and generates .class files inside the BUILD folder.

-----------------------------------------------------------------------
## Instruction to run:

####Command: ant -buildfile racingDrivers/src/build.xml run -Darg0=<input_file.txt> -Darg1=<output_file.txt> -Darg2=<Debug_value>

Note: Arguments accept the absolute path of the files.


-----------------------------------------------------------------------
## Description:

Developed a project where given number of drivers are competing with each other and the data is given in
input file.

driverPosition(double value, double array) : I used binary search to determine the position of the input value. 
Since Binary search requires the values to be sorted at first which in our case is fulfilled so I took advantage 
of that and used it. The Time complexity using this came to be logN.

I used BubbleSort to sort the array to find the position of the driver.

There are 5 debug values used return in MyLogger.java. We pass the needed debug_value using Command Line according to which 
different log messages are displayed on Command Line.

I took help from tutorialspoint to create the state pattern. So some code may be matching with the code present
on the tutorialspoint.



-----------------------------------------------------------------------
### Academic Honesty statement:
-----------------------------------------------------------------------

"I have done this assignment completely on my own. I have not copied
it, nor have I given my solution to anyone else. I understand that if
I am involved in plagiarism or cheating an official form will be
submitted to the Academic Honesty Committee of the Watson School to
determine the action that needs to be taken. "

Date: 06/28/2019


