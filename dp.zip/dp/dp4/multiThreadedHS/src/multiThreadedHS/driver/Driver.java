package multiThreadedHS.driver;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.io.*;
import multiThreadedHS.util.FileProcessor;
import multiThreadedHS.util.Results;
import multiThreadedHS.util.MyLogger;
import multiThreadedHS.util.MyLogger.DebugLevel;
import multiThreadedHS.threads.ThreadWorker;

public class Driver {
	public static void main(String[] args) throws FileNotFoundException {

		/*
		 * As the build.xml specifies the arguments as argX, in case the
		 * argument value is not given java takes the default value specified in
		 * build.xml. To avoid that, below condition is used
		 */
			System.out.println("Hello World! Lets get started with the assignment");	
				
			int n = Integer.parseInt(args[0]);
			int debugValue=0;
			String outputFile=null;
			if(n<1 || n>3)
					System.out.println("The value of N should be between 1 to 3");
			else{
				if(n==1){
					if (args.length != 4) {

						System.err.println("Error: You need to give 4 arguements.");
						System.exit(0);
					}
					if (args[0].equals("${arg0}") || args[1].equals("${arg1}") || args[2].equals("${arg2}") || args[3].equals("${arg3}")) {

						System.err.println("Error: Incorrect Arguements Passed");
						System.exit(0);
					}
					debugValue = Integer.parseInt(args[3]);
					outputFile = args[2];
				}
				else if(n==2){
					if (args.length != 5) {

						System.err.println("Error: You need to give 5 arguements.");
						System.exit(0);
					}
					if (args[0].equals("${arg0}") || args[1].equals("${arg1}") || args[2].equals("${arg2}") || args[3].equals("${arg3}") || args[4].equals("${arg4}")) {

						System.err.println("Error: Incorrect Arguements Passed");
						System.exit(0);
					}
					debugValue = Integer.parseInt(args[4]);
					outputFile = args[3];
				}
				else{
					if (args.length != 6) {

						System.err.println("Error: You need to give 6 arguements.");
						System.exit(0);
					}
					if (args[0].equals("${arg0}") || args[1].equals("${arg1}") || args[2].equals("${arg2}") || args[3].equals("${arg3}") || args[4].equals("${arg4}") || args[5].equals("${arg5}")) {

						System.err.println("Error: Incorrect Arguements Passed");
						System.exit(0);
					}
					debugValue = Integer.parseInt(args[5]);
					outputFile = args[4];
				}
			}
			
			/*Debugging*/
			MyLogger.setDebugValue(debugValue);
			Results r1 = new Results();
			try{
				if(n<1 || n>3)
					System.out.println("The value of N should be between 1 to 3");
				else{
					
					//System.out.println("Value from user is " +n);
					
					
					if(n==1){
						/*FileProcessor called here*/
						FileProcessor finput1 = new FileProcessor();
						finput1.initializeFile(args[1]);
						
						ThreadWorker tw1 = new ThreadWorker(finput1,r1);					
						Thread t1 =new Thread(tw1);  
						t1.start();
						MyLogger.writeMessage ("Thread t1 running",DebugLevel.THREADS);
						
						// wait for threads to end 
						try{ 
							t1.join(); 
						} 
						catch(Exception e){ 
							System.out.println("Interrupted"); 
						}
						finally{}
						
					}
					else if(n==2){
						/*FileProcessor called here*/
						FileProcessor finput1 = new FileProcessor();
						finput1.initializeFile(args[1]);
						
						FileProcessor finput2 = new FileProcessor();
						finput2.initializeFile(args[2]);
						
						ThreadWorker tw1 = new ThreadWorker(finput1,r1);
						ThreadWorker tw2 = new ThreadWorker(finput2,r1);
						
						Thread t1 =new Thread(tw1); 
						Thread t2 =new Thread(tw2);  					
						
						t1.start();
						MyLogger.writeMessage ("Thread t1 running",DebugLevel.THREADS);
						t2.start();
						MyLogger.writeMessage ("Thread t2 running",DebugLevel.THREADS);
						
						// wait for threads to end 
						try{ 
							t1.join(); 
							t2.join();
						} 
						catch(Exception e){ 
							System.out.println("Interrupted"); 
						}
						finally{}
					}
					else{
						/*FileProcessor called here*/
						FileProcessor finput1 = new FileProcessor();
						finput1.initializeFile(args[1]);
						
						FileProcessor finput2 = new FileProcessor();
						finput2.initializeFile(args[2]);
						
						FileProcessor finput3 = new FileProcessor();
						finput3.initializeFile(args[3]);
						
						ThreadWorker tw1 = new ThreadWorker(finput1,r1);
						ThreadWorker tw2 = new ThreadWorker(finput2,r1);
						ThreadWorker tw3 = new ThreadWorker(finput3,r1);
						
						Thread t1 =new Thread(tw1);
						Thread t2 =new Thread(tw2);  
						Thread t3 =new Thread(tw3);						
						
						t1.start();
						MyLogger.writeMessage ("Thread t1 running",DebugLevel.THREADS);
						t2.start();
						MyLogger.writeMessage ("Thread t2 running",DebugLevel.THREADS);						
						t3.start();
						MyLogger.writeMessage ("Thread t3 running",DebugLevel.THREADS);
						// wait for threads to end 
						try{ 
							t1.join();							
							t2.join();
							t3.join();
						} 
						catch(Exception e){ 
							System.out.println("Interrupted"); 
						}
						finally{}
						
					}
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
			finally{}
		
		
		/* Writing to file done here using the same instance we are using in ThreadWorker*/	
		r1.writeToFile(outputFile);
		/*Printing Final Array*/
		r1.printFinalArray();
	}	
}


