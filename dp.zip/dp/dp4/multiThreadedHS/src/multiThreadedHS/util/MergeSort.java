package multiThreadedHS.util;

import java.util.ArrayList;
import multiThreadedHS.util.MyLogger.DebugLevel;
import multiThreadedHS.util.MyLogger;

public class MergeSort{
	
	private ArrayList<Integer> inputArray;
	
	/**
	* @param get the list to be sorted
	* return the sorted List          
	*/
	public ArrayList<Integer> getSortedArray() {
        return inputArray;
    }
    
	
	/**
	* @param get the list to be sorted
	* Constructor 
	*/
    public MergeSort(ArrayList<Integer> inputArray){
		MyLogger.writeMessage ("MergeSort Constructor called",DebugLevel.CONSTRUCTOR);
        this.inputArray = inputArray;
    }
    
	
	/**
	* @param nothing
	* It will call the divide method   
	* return nothing
	*/
    public void sortGivenArray(){       
        divide(0, this.inputArray.size()-1);
    }
    
	
	
	
	/**
	* @param the start index and ending index of List to be sorted
	* It will divide the List into many List recursively and call merger at the end        
	*/
    public void divide(int startIndex,int endIndex){
        
        //Divide till you breakdown your list to single element
        if(startIndex<endIndex && (endIndex-startIndex)>=1){
            int mid = (endIndex + startIndex)/2;
            divide(startIndex, mid);
            divide(mid+1, endIndex);        
            
            //merging Sorted array produce above into one sorted array
            merger(startIndex,mid,endIndex);            
        }       
    }   
    
	
	
	
	/**
	* @param the start index, mid Index and ending index from divide method
	* It will merge and call the main method recursively      
	* return
	*/
    public void merger(int startIndex,int midIndex,int endIndex){
        
        //Below is the mergedarray that will be sorted array Array[i-midIndex] , Array[(midIndex+1)-endIndex]
        ArrayList<Integer> mergedSortedArray = new ArrayList<Integer>();
        
        int leftIndex = startIndex;
        int rightIndex = midIndex+1;
        
        while(leftIndex<=midIndex && rightIndex<=endIndex){
            if(inputArray.get(leftIndex)<=inputArray.get(rightIndex)){
                mergedSortedArray.add(inputArray.get(leftIndex));
                leftIndex++;
            }else{
                mergedSortedArray.add(inputArray.get(rightIndex));
                rightIndex++;
            }
        }       
        
        //Either of below while loop will execute
        while(leftIndex<=midIndex){
            mergedSortedArray.add(inputArray.get(leftIndex));
            leftIndex++;
        }
        
        while(rightIndex<=endIndex){
            mergedSortedArray.add(inputArray.get(rightIndex));
            rightIndex++;
        }
        
        int i = 0;
        int j = startIndex;
        //Setting sorted array to original one
        while(i<mergedSortedArray.size()){
            inputArray.set(j, mergedSortedArray.get(i++));
            j++;
        }
    }
	
	
	
}
