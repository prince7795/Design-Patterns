package multiThreadedHS.util;

public interface StdoutDisplayInterface {

	public void writeToStdout(String s);
}