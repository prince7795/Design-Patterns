package multiThreadedHS.util;
	
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import multiThreadedHS.util.MyLogger.DebugLevel;
import multiThreadedHS.util.MyLogger;
import multiThreadedHS.structure.datastructure;

public class Results implements FileDisplayInterface, StdoutDisplayInterface {

	/**Declaring a data structure 
	**/
	private ArrayList<Integer> finRes=new ArrayList<Integer>();
	private List<String> resultList=new Vector<String>();
	
	/**
	Declaring an empty String to store the result got from test file
	**/
	String res = "";

	/**
	* @param the string which needs to be stored
	* Store the result in the list
	* @return nothing
	*/
	public void storeNewResult(String res) {
		resultList.add(res);
		//writeToStdout(res);
	}
	
	
	/**
	* @param the string which needs to be printed
	* Directly print to command line
	* @return nothing
	*/
	public void writeToStdout(String s) {
		System.out.println(s + " Hello");
	}
	
	
	/**
	* @param the string which needs to be printed
	* It will call buffered reader and write it to the output file
	* @return nothing
	*/
	public void writeToFile(String s) 
	{
		MergeSort data = new MergeSort(finRes);
		
		data.sortGivenArray();
		finRes = data.getSortedArray();
		addToVector();	
		
		
		
		/* Writing to a file using BufferedWriter in Java*/
        try {
			MyLogger.writeMessage ("Output File Opened Here",DebugLevel.OUTPUTFILEOPERATION);
            FileWriter writer = new FileWriter(s);
            BufferedWriter bwr = new BufferedWriter(writer);
            for(String st : resultList){	
				bwr.write(st);
				//bwr.write(" ");
				//bwr.newLine();
				bwr.write("\r\n");
			}
            bwr.close(); 
			MyLogger.writeMessage ("Output File closed Here",DebugLevel.OUTPUTFILEOPERATION);
			MyLogger.writeMessage ("Output File released Here",DebugLevel.RELEASE);
        } 
		catch (Exception ioe) {
            System.out.println("Invalid");
        }
		
	}
	
	
	
	/**
	* @param the integer which needs to be stored
	* Store the result in the ArrayList
	* @return nothing
	*/
	public void insert(Integer val) {
		finRes.add(val);	
		//writeToStdout(res);
	}
	
	
	/**
	* @param nothing
	* store the result in arraylist into Vector list for BufferedWriter
	* @return nothing
	*/
	public void addToVector() {
		for(int i=0;i<finRes.size();i++){
			resultList.add(String.valueOf(finRes.get(i)));
		}
	}
	
	public void printFinalArray(){
		for(int i=0;i<finRes.size();i++)
			System.out.println(finRes.get(i));
	}
	
	
}
