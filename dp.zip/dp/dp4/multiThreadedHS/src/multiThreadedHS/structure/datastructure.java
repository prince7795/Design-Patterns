package multiThreadedHS.structure;

import multiThreadedHS.util.Results;
import java.util.List;
import java.util.ArrayList;
import multiThreadedHS.util.MyLogger.DebugLevel;
import multiThreadedHS.util.MyLogger;
import multiThreadedHS.util.FileProcessor;	
import multiThreadedHS.util.MergeSort;

	
public class datastructure{	
	
	
	/**
	* @param finput1: get the FileProcessor object from Driver.java
	* Store the data got from read line into arrays 
	* return arr1: array is returned
	*/
	public synchronized ArrayList<Integer> getData(FileProcessor finput1){
		
		/*
		* Input File Reading done here
		*/
		
		ArrayList<Integer> arr1 = new ArrayList<Integer>();
		
		String myString="";
		while((myString = finput1.readLine()) != null){
			if(Integer.parseInt(myString)<10000 || Integer.parseInt(myString)>99999){}
			else
				arr1.add(Integer.parseInt(myString));
			}
			
		return arr1;
		
	}
}