package multiThreadedHS.threads;

import multiThreadedHS.util.Results;
import multiThreadedHS.util.MyLogger.DebugLevel;
import multiThreadedHS.util.MyLogger;
import multiThreadedHS.util.FileProcessor;
import multiThreadedHS.structure.datastructure;
import java.util.List;
import java.util.ArrayList;
import multiThreadedHS.util.MergeSort;

public class ThreadWorker implements Runnable{
	private FileProcessor finput1;
	private Results res;
	private ArrayList<Integer> threadArr = new ArrayList<Integer>();
	datastructure ds = new datastructure();
	
	public ThreadWorker(FileProcessor fp1, Results r){
		MyLogger.writeMessage ("ThreadWorker Constructor called",DebugLevel.CONSTRUCTOR);
		finput1=fp1;
		res = r;
	}
	
	
	
	public synchronized void run(){  
		
		threadArr = ds.getData(finput1);
		for (int i=0; i<threadArr.size(); i++) {
				//System.out.println(threadArr.get(i));
		}
		MergeSort ms = new MergeSort(threadArr);
		ms.sortGivenArray();
       // System.out.println("\n------------Sorted Array------------");
		threadArr = ms.getSortedArray();
		for (int i=0; i<threadArr.size(); i++) {
				//System.out.println(threadArr.get(i));
				res.insert(threadArr.get(i));
		}
	}
		
}