# CSX42: Assignment 4
## Name: Prince Rajaram Singh	
### BNumber: B00767056

-----------------------------------------------------------------------
-----------------------------------------------------------------------


Following are the commands and the instructions to run ANT on your project.
#### Note: build.xml is present in multiThreadedHS/src folder.

-----------------------------------------------------------------------
## Instruction to clean:

####Command: 
ant -buildfile multiThreadedHS/src/build.xml clean

Description: It cleans up all the .class files that were generated when you
compiled your code.

-----------------------------------------------------------------------
## Instruction to compile:

####Command: ant -buildfile multiThreadedHS/src/build.xml all

Description: Compiles your code and generates .class files inside the BUILD folder.

-----------------------------------------------------------------------
## Instruction to run:

####Command: 

ant -buildfile multiThreadedHS/src/build.xml run -Dargs"<NoOfInputFiles> <input1.txt> <input2.txt> <input3.txt> <output.txt> <debugValue>"


-----------------------------------------------------------------------
## Description:
This Assignment implements MultiThreading in java to read values from multiple input files and store it into a single output file.
Each thread will work on a datastructure(ArrayList) which is private to ThreadWorker class. After performing MergeSort to that
ArrayList each thread will try to access a datastructure(ArrayList) which will be a datamember of Results class which will be common 
to all threads. The same instance of this Results class is passed to each Thread in ThreadWorker so that they write to same List.

Justification for DataStructure used:
I used ArrayList for both Threads and Results. ArrayList provides us with methods which are easy to work with. Also while 
initializing a ArrayList we do not need to specify size before working on it. Also we can dynamically add or remove elements
from ArrayList as per as our requirement.

I created a sperate package named structure which contains datastructure class which will call readline method from FileProcessor and return the 
created array.

ThreadWorker class which extends runnable contains the run method for thread. The run method calls all the methods to move head.

For sorting elements in ArrayList, mergesort was used. I took help from withexample.com for impplementation of mergesort on
a ArrayList.
Citation: https://www.withexample.com/merge-sort-using-arraylist-java-example/

-----------------------------------------------------------------------
### Academic Honesty statement:
-----------------------------------------------------------------------

"I have done this assignment completely on my own. I have not copied
it, nor have I given my solution to anyone else. I understand that if
I am involved in plagiarism or cheating I will have to sign an
official form that I have cheated and that this form will be stored in
my official university record. I also understand that I will receive a
grade of 0 for the involved assignment for my first offense and that I
will receive a grade of F for the course for any additional
offense.""

Date: 7-22-2019


